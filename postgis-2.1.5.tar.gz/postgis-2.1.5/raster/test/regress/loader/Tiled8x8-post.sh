rm -f loader/Tiled8x8.tif
